﻿namespace Shapes
{
    interface IDrawable
    {
        void Draw();
    }
}
