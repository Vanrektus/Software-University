﻿namespace Cars
{
    public interface IElectricCar
    {
        //---------------------------Properties---------------------------
        int Battery { get; set; }
    }
}
