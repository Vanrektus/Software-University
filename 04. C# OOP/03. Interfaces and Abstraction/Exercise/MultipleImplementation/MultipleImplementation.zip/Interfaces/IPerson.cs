﻿namespace PersonInfo
{
    public interface IPerson
    {
        //---------------------------Properties---------------------------
        string Name { get; }
        int Age { get; }
    }
}
