﻿namespace PersonInfo
{
    public interface IIdentifiable
    {
        //---------------------------Properties---------------------------
        string Id { get; }
    }
}
