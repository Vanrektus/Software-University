﻿namespace PersonInfo
{
    public interface IBirthable
    {
        //---------------------------Properties---------------------------
        string Birthdate { get; }
    }
}
