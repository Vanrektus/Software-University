﻿namespace Telephony
{
    interface IBrowseable
    {
        //---------------------------Methods---------------------------
        string Browse(string url);
    }
}
