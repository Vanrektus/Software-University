﻿namespace Telephony
{
    public interface ICallable
    {
        //---------------------------Methods---------------------------
        string Call(string number);
    }
}
