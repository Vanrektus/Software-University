﻿namespace BorderControl
{
    public interface IBuyer
    {
        //---------------------------Properties---------------------------
        int Food { get; }

        //---------------------------Methods---------------------------
        void BuyFood();
    }
}
