﻿namespace BorderControl
{
    public interface IIdentifiable
    {
        //---------------------------Properties---------------------------
        string Id { get; }
    }
}
