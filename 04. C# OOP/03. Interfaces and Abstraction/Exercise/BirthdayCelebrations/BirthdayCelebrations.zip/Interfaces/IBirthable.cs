﻿namespace BorderControl
{
    public interface IBirthable
    {
        //---------------------------Properties---------------------------
        string Birthdate { get; }
    }
}
