﻿namespace Restaurant
{
    public class ColdBeverage : Beverage
    {
        //---------------------------Constructors---------------------------
        public ColdBeverage(string name, decimal price, double milliliters)
            : base(name, price, milliliters)
        {

        }
    }
}
