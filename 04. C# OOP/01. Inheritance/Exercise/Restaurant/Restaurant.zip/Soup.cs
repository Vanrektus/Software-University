﻿namespace Restaurant
{
    public class Soup : Starter
    {
        //---------------------------Constructors---------------------------
        public Soup(string name, decimal price, double grams)
            : base(name, price, grams)
        {

        }
    }
}
