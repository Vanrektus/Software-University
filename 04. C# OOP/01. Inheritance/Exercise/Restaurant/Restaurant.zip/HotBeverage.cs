﻿namespace Restaurant
{
    public class HotBeverage : Beverage
    {
        //---------------------------Constructors---------------------------
        public HotBeverage(string name, decimal price, double milliliters)
            : base(name, price, milliliters)
        {

        }
    }
}
