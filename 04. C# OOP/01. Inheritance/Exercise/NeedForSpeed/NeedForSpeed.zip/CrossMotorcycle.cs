﻿namespace NeedForSpeed
{
    public class CrossMotorcycle : Motorcycle
    {
        //---------------------------Constructors---------------------------
        public CrossMotorcycle(int horsePower, double fuel)
            : base(horsePower, fuel)
        {

        }
    }
}
