﻿namespace NeedForSpeed
{
    public class Motorcycle : Vehicle
    {
        //---------------------------Constructors---------------------------
        public Motorcycle(int horsePower, double fuel)
            : base(horsePower, fuel)
        {

        }
    }
}
