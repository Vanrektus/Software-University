﻿namespace PlayersAndMonsters
{
    public class Elf : Hero
    {
        //---------------------------Constructors---------------------------
        public Elf(string username, int level)
            : base(username, level)
        {

        }
    }
}
