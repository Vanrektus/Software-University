﻿namespace LoggerLibrary.Core
{
    public interface IEngine
    {
        //---------------------------Methods---------------------------
        void Run();
    }
}
