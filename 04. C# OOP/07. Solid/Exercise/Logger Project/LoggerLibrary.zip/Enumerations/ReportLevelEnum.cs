﻿namespace LoggerLibrary.Enumerations
{
    public enum ReportLevelEnum
    {
        //---------------------------Enumerators---------------------------
        Info = 1,
        Warning,
        Error,
        Critical,
        Fatal
    }
}
