﻿namespace LoggerLibrary.Interfaces
{
    public interface ILayout
    {
        //---------------------------Properties---------------------------
        string Template { get; }
    }
}
