﻿namespace LoggerLibrary.IO
{
    public interface IReader
    {
        //---------------------------Methods---------------------------
        string ReadLine();
    }
}
