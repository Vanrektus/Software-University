﻿namespace Vehicles
{
    public abstract class Vehicle
    {
        //---------------------------Methods---------------------------
        public abstract string Drive(double km);

        public abstract void Refuel(double km);
    }
}
