﻿namespace WildFarm.IO
{
    public interface IReader
    {
        //---------------------------Methods---------------------------
        public string ReadLine();
    }
}
