﻿namespace WildFarm.Core
{
    public interface IEngine
    {
        //---------------------------Methods---------------------------
        public void Run();
    }
}
