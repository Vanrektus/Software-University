﻿namespace WildFarm
{
    public interface ISoundProducible
    {
        //---------------------------Methods---------------------------
        void ProduceSound();
    }
}
