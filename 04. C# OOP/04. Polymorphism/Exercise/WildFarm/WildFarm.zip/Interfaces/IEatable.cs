﻿namespace WildFarm
{
    public interface IEatable
    {
        //---------------------------Methods---------------------------
        void Eat(Food food);
    }
}
