﻿namespace WildFarm.Interfaces
{
    public interface IFood
    {
        //---------------------------Properties---------------------------
        public int Quantity { get; }
    }
}
