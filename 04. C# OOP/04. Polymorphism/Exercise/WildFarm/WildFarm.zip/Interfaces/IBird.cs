﻿namespace WildFarm.Interfaces
{
    public interface IBird
    {
        //---------------------------Properties---------------------------
        public double WingSize { get; }
    }
}
