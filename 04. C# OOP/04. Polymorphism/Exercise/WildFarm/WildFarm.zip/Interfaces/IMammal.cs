﻿namespace WildFarm.Interfaces
{
    public interface IMammal
    {
        //---------------------------Properties---------------------------
        public string LivingRegion { get; }
    }
}
