﻿namespace WildFarm.Interfaces
{
    public interface IFeline
    {
        //---------------------------Properties---------------------------
        public string Breed { get; }
    }
}
