﻿namespace WildFarm
{
    public class Fruit : Food
    {
        //---------------------------Constructors---------------------------
        public Fruit(int quantity)
            : base(quantity)
        {

        }
    }
}
