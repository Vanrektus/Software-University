﻿namespace WildFarm
{
    public class Seeds : Food
    {
        //---------------------------Constructors---------------------------
        public Seeds(int quantity)
            : base(quantity)
        {

        }
    }
}
