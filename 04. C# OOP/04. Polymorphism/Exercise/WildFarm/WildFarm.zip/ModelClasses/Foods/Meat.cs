﻿namespace WildFarm
{
    public class Meat : Food
    {
        //---------------------------Constructors---------------------------
        public Meat(int quantity)
            : base(quantity)
        {

        }
    }
}
