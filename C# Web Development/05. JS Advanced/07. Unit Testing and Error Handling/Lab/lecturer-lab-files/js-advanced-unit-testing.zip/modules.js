const calculator = require('./calc-module');

console.log(calculator(2, 19));
