function calc(a, b) {
    return a + b;
};

function print(name) {
    console.log(name);
}

module.exports = calc;