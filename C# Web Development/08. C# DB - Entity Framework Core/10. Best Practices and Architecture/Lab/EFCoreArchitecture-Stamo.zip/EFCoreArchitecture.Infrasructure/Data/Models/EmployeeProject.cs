﻿namespace EFCoreArchitecture.Infrastructure.Data.Models
{
    public class EmployeeProject
    {
        public string EmployeeName { get; set; }

        public string ProjectName { get; set; }
    }
}
