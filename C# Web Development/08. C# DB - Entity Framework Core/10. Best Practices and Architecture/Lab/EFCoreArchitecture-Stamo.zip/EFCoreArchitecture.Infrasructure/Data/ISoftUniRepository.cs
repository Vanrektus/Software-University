﻿using EFCoreArchitecture.Infrastructure.Data.Common;

namespace EFCoreArchitecture.Infrastructure.Data
{
    public interface ISoftUniRepository : IRepository
    {
    }
}
