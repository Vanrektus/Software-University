﻿namespace P03_FootballBetting.Data.Models.Enums
{
    public enum Prediction
    {
        Lost = 1,
        Draw = 2,
        Win = 3,
    }
}
