﻿namespace P03_FootballBetting.Data.Models.Enums
{
    public enum Prediction
    {
        Lost = 10,
        Draw = 20,
        Win = 30,
    }
}
