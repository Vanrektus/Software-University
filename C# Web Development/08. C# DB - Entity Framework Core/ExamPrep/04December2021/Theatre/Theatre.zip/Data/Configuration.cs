﻿namespace Theatre.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=.;Database=Artillery;User Id=sa;Password=SoftUni!2022;TrustServerCertificate=True";
    }
}
