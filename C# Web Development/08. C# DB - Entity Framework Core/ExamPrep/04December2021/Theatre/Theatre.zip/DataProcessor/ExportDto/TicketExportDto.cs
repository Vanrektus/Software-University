﻿namespace Theatre.DataProcessor.ExportDto
{
    public class TicketExportDto
    {
        public decimal Price { get; set; }

        public sbyte RowNumber { get; set; }
    }
}
