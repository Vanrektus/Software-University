﻿namespace Artillery.DataProcessor.ExportDto
{
    public class ShellGunExportDto
    {
        public string GunType { get; set; }

        public int GunWeight { get; set; }

        public double BarrelLength { get; set; }

        public string Range { get; set; }
    }
}
