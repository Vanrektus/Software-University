﻿namespace Footballers.Data
{
    public class Configuration
    {
        public static string ConnectionString = @"Server=.;Database=Footballers;User Id=sa;Password=SoftUni!2022;TrustServerCertificate=True";
    }
}
