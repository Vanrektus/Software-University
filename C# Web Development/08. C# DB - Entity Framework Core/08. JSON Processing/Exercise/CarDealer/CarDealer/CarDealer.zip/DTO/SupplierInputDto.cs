﻿namespace CarDealer.DTO
{
    public class SupplierInputDto
    {
        public string Name { get; set; }

        public bool IsImporter { get; set; }
    }
}
