﻿namespace P03_FootballBetting.Data.Models.Enums
{
    public enum Prediction
    {
        Lost = -1,
        Draw = 0,
        Win = 1,
    }
}
