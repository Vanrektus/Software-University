﻿using MyQuizApplication.Infrastructure.Data.Common;

namespace MyQuizApplication.Infrastructure.Data
{
    public interface IQuizRepository : IRepository
    {
    }
}
