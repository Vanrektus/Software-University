﻿namespace BookShop.Models.Enums
{
    public enum AgeRestriction
    {
        Minor = 10,
        Teen = 20,
        Adult = 30,
    }
}
