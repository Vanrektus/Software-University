﻿namespace BookShop.Models.Enums
{
    public enum EditionType
    {
        Normal = 10,
        Promo = 20,
        Gold = 30,
    }
}
