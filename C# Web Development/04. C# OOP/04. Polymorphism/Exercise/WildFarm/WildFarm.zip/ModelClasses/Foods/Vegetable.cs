﻿namespace WildFarm
{
    public class Vegetable : Food
    {
        //---------------------------Constructors---------------------------
        public Vegetable(int quantity)
            : base(quantity)
        {

        }
    }
}
