﻿namespace WildFarm.Core
{
    public interface IEngine
    {
        //---------------------------Methods---------------------------
        void Run();
    }
}
