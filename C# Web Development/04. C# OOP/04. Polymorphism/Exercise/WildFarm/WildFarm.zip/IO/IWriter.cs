﻿namespace WildFarm.IO
{
    public interface IWriter
    {
        //---------------------------Methods---------------------------
        void Write(string text);
        void WriteLine(string text);
    }
}
