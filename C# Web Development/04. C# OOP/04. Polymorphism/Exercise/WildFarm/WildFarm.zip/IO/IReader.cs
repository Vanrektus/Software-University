﻿namespace WildFarm.IO
{
    public interface IReader
    {
        //---------------------------Methods---------------------------
        string ReadLine();
    }
}
