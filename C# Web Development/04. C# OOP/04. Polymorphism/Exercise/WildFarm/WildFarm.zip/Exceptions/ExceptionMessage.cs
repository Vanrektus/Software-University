﻿namespace WildFarm.Exceptions
{
    public static class ExceptionMessage
    {
        //---------------------------Constants---------------------------
        public const string InvalidFoodException = "{0} does not eat {1}!";
    }
}
