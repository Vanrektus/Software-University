﻿namespace WildFarm.Interfaces
{
    public interface IBird
    {
        //---------------------------Properties---------------------------
        double WingSize { get; }
    }
}
