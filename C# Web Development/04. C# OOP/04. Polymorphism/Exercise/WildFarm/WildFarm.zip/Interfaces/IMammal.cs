﻿namespace WildFarm.Interfaces
{
    public interface IMammal
    {
        //---------------------------Properties---------------------------
        string LivingRegion { get; }
    }
}
