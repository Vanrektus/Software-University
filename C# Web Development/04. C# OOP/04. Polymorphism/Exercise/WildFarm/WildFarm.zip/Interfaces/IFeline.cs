﻿namespace WildFarm.Interfaces
{
    public interface IFeline
    {
        //---------------------------Properties---------------------------
        string Breed { get; }
    }
}
