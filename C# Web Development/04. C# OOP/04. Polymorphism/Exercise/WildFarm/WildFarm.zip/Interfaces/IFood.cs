﻿namespace WildFarm.Interfaces
{
    public interface IFood
    {
        //---------------------------Properties---------------------------
        int Quantity { get; }
    }
}
