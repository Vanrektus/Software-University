﻿//using FakeAxeAndDummy.Contracts;
using FakeAxeAndDummy.Tests.Models;
using NUnit.Framework;

[TestFixture]
public class HeroTests
{
    //---------------------------Fields---------------------------
    private string name;
    private IWeapon fakeAxe;
    private ITarget fakeDummy;
    private Hero hero;

    //---------------------------SET UP---------------------------
    [SetUp]
    public void Setup()
    {
        this.name = "Pesho";
        this.fakeAxe = new FakeWeapon();
        this.fakeDummy = new FakeTarget();
        this.hero = new Hero(this.name, this.fakeAxe);
    }

    //---------------------------HERO TESTS---------------------------
    [Test]
    public void GainXPWhenTargetIsDead()
    {
        this.hero.Attack(this.fakeDummy);

        Assert.That(this.hero.Experience, Is.EqualTo(20));
    }
}