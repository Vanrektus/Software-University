﻿//using FakeAxeAndDummy.Contracts;

namespace FakeAxeAndDummy.Tests.Models
{
    public class FakeWeapon : IWeapon
    {
        //---------------------------Properties---------------------------
        public int AttackPoints => 100;

        public int DurabilityPoints => 100;

        //---------------------------Methods---------------------------
        public void Attack(ITarget target)
        {
            target.TakeAttack(AttackPoints);
        }
    }
}
