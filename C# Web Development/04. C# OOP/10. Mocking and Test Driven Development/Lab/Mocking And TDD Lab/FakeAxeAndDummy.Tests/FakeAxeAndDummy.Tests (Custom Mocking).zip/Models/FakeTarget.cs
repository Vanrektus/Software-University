﻿//using FakeAxeAndDummy.Contracts;

namespace FakeAxeAndDummy.Tests.Models
{
    public class FakeTarget : ITarget
    {
        //---------------------------Properties---------------------------
        public int Health => 10;

        //---------------------------Methods---------------------------
        public int GiveExperience() => 20;

        public bool IsDead() => true;

        public void TakeAttack(int attackPoints)
        {

        }
    }
}
