﻿using System;

namespace EgnValidatorProgram
{
    public class EgnInfo
    {
        public string City { get; set; }

        public DateTime BirthDate { get; set; }

        public Gender Gender { get; set; }
    }
}