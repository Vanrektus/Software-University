﻿namespace MockingDemo
{
    public interface IWriter
    {
        void Write(string text);
    }
}
