﻿namespace PlayersAndMonsters
{
    public class MuseElf : Elf
    {
        //---------------------------Constructors---------------------------
        public MuseElf(string username, int level) 
            : base(username, level)
        {

        }
    }
}
