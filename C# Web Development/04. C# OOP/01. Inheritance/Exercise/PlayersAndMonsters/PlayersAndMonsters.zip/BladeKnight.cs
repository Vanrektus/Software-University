﻿namespace PlayersAndMonsters
{
    public class BladeKnight : DarkKnight
    {
        //---------------------------Constructors---------------------------
        public BladeKnight(string username, int level) 
            : base(username, level)
        {

        }
    }
}
