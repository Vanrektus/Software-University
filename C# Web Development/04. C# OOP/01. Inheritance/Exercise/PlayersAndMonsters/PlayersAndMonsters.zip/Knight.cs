﻿namespace PlayersAndMonsters
{
    public class Knight : Hero
    {
        //---------------------------Constructors---------------------------
        public Knight(string username, int level) 
            : base(username, level)
        {

        }
    }
}
