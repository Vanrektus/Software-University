﻿namespace PlayersAndMonsters
{
    public class DarkWizard : Wizard
    {
        //---------------------------Constructors---------------------------
        public DarkWizard(string username, int level) 
            : base(username, level)
        {

        }
    }
}
