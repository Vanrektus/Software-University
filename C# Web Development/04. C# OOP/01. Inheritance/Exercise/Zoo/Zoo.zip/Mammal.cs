﻿namespace Zoo
{
    public class Mammal : Animal
    {
        //---------------------------Constructors---------------------------
        public Mammal(string name)
            : base(name)
        {

        }
    }
}
