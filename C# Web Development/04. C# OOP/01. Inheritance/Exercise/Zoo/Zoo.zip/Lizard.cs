﻿namespace Zoo
{
    public class Lizard : Reptile
    {
        //---------------------------Constructors---------------------------
        public Lizard(string name)
            : base(name)
        {

        }
    }
}
