﻿namespace Zoo
{
    public class Reptile : Animal
    {
        //---------------------------Constructors---------------------------
        public Reptile(string name)
            :base(name)
        {

        }
    }
}
