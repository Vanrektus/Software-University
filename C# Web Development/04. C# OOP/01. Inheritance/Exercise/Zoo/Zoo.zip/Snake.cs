﻿namespace Zoo
{
    public class Snake : Reptile
    {
        //---------------------------Constructors---------------------------
        public Snake(string name)
            : base(name)
        {

        }
    }
}
