﻿namespace Zoo
{
    public class Bear : Mammal
    {
        //---------------------------Constructors---------------------------
        public Bear(string name)
            : base(name)
        {

        }
    }
}
