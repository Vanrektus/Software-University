﻿namespace Zoo
{
    public class Gorilla : Mammal
    {
        //---------------------------Constructors---------------------------
        public Gorilla(string name)
            : base(name)
        {

        }
    }
}
