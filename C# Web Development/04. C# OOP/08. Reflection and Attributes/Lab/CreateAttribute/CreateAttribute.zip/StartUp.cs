﻿using System;

namespace AuthorProblem
{
    [Author("Vancho")]
    public class StartUp
    {
        [Author("Pack Vancho")]
        static void Main(string[] args)
        {

        }
    }
}
