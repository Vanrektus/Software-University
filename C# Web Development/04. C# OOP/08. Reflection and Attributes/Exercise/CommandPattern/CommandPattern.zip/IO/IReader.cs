﻿namespace CommandPattern.IO
{
    public interface IReader
    {
        //---------------------------Methods---------------------------
        string ReadLine();
    }
}
